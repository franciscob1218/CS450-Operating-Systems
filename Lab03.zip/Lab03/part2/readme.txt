Deimantas Gilys #A20434583
Francisco Barba Cuellar #A20121767
Nathan Cook #A20458336


This a readme for compilation and running of xv6-riscv lab3_git

compilation
-----------
1. assuming everything is unzipped run:
    cd xv6-riscv-modded-CS450:
2. assuming you have qemu setup correctly run: 
    make clean && make qemu
3. You should be inside xv6

running
-------
1. to run whereIs run inside xv6:
    whereIs va 
    *where va is the virtual address
2. to run yesWritable type:
    yesWritable va
    *where va is the virtual address
3. to run yesWritable type:
    isWritable va
    *where va is the virtual address
4. to run yesWritable type:
    notWritable va
    *where va is the virtual address
